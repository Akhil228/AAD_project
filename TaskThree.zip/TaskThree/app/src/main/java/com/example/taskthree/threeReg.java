package com.example.taskthree;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class threeReg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three_reg);
    }
}